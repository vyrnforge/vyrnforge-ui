# React Docs Route Map

## Recommended routes

```txt
/
/overview
/core/tokens
/core/themes
/core/density
/core/css-overrides
/components/actions
/components/typography
/components/forms
/components/feedback
/components/overlays
/components/layout
/components/navigation
/components/data-display
/data-grid/basic
/data-grid/columns
/data-grid/filtering
/data-grid/selection
/data-grid/grouping
/data-grid/server-mode
/data-grid/export-request
/data-grid/saved-views
/patterns/admin-shell
/patterns/resource-detail
/patterns/settings
/patterns/form-page
/patterns/data-management-page
/ai/context
/ai/component-map
/ai/prompts
```

## Route rules

- Component docs should not be mixed into grid docs.
- Grid docs should focus only on grid behavior.
- Pattern pages should demonstrate real product composition.
- AI pages should provide machine-readable guidance and examples.
