# ComponentName

## Status

- Package: `@dravyn/ui-components`
- Status: Draft | Experimental | Stable
- Owner: Dravyn UI maintainers

## Purpose

Describe what this component solves.

## When to use

- Use case 1
- Use case 2

## When not to use

- Non-use case 1
- Non-use case 2

## Import

```tsx
import { ComponentName } from "@dravyn/ui-components";
import "@dravyn/ui-core/styles/index.css";
import "@dravyn/ui-components/styles/index.css";
```

## Basic usage

```tsx
<ComponentName />
```

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `className` | `string` | - | Custom class. |
| `style` | `React.CSSProperties` | - | Instance style override. |

## Accessibility

- Requirement 1
- Requirement 2

## Theming

Uses `--dv-*` tokens.

## AI usage notes

- Required imports.
- Required accessibility props.
- State ownership notes.
- Do not use for X.

## Related components

- Related component 1
