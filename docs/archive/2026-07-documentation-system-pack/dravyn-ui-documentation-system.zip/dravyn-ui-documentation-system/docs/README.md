# Dravyn UI Documentation Index

This is the canonical documentation index for Dravyn UI.

Do not create new top-level documentation without linking it from this file.

## 1. Governance

| Document | Purpose |
| --- | --- |
| `governance/00-documentation-governance.md` | Rules for creating, updating, archiving, and avoiding duplicate docs. |
| `governance/01-project-source-of-truth.md` | Canonical definition of what Dravyn UI is and is not. |
| `governance/02-document-lifecycle.md` | Draft/stable/deprecated/archive lifecycle. |
| `governance/03-naming-and-terminology.md` | Required package names, prefixes, and vocabulary. |

## 2. Architecture

| Document | Purpose |
| --- | --- |
| `architecture/00-system-overview.md` | High-level package architecture. |
| `architecture/01-package-boundaries.md` | What each package owns and must not own. |
| `architecture/02-state-and-adapter-ownership.md` | State distribution, adapters, Redux policy. |
| `architecture/03-theming-and-styling.md` | CSS variable, token, and styling rules. |
| `architecture/04-clean-code-boundaries.md` | Components vs hooks vs core vs adapters. |
| `architecture/05-accessibility-standards.md` | Accessibility baseline. |

## 3. Roadmap

| Document | Purpose |
| --- | --- |
| `roadmap/00-master-roadmap.md` | Sprint-level execution plan. |
| `roadmap/01-component-inventory.md` | Current/planned components and maturity status. |
| `roadmap/02-gap-analysis.md` | Missing areas and priorities. |
| `roadmap/03-do-not-build-yet.md` | Explicit non-goals and deferred work. |

## 4. Package Docs

| Document | Purpose |
| --- | --- |
| `packages/ui-core.md` | Tokens, themes, density, utilities. |
| `packages/ui-components.md` | Shared React primitives and application components. |
| `packages/ui-data-grid.md` | UniversalDataGrid package scope and API direction. |

## 5. React Documentation App

| Document | Purpose |
| --- | --- |
| `react-docs/00-react-docs-app-spec.md` | Specification for the human-facing docs/playground app. |
| `react-docs/01-route-map.md` | Required route structure. |
| `react-docs/02-example-standards.md` | Rules for examples, snippets, and use-case pages. |
| `react-docs/03-ai-readable-docs.md` | How docs should expose machine-readable context. |

## 6. AI Documentation

| Document | Purpose |
| --- | --- |
| `.ai/AI_CONTEXT.md` | Primary AI context file. |
| `.ai/REPO_MAP.md` | AI-readable repo structure guide. |
| `.ai/CODING_RULES.md` | Implementation rules for agents. |
| `.ai/DOC_USAGE_GUIDE.md` | How AI should read and update docs. |
| `AGENTS.md` | Root instruction file for Codex/agents. |

## 7. Templates

| Template | Purpose |
| --- | --- |
| `templates/component-doc-template.md` | Standard component docs. |
| `templates/package-readme-template.md` | Standard package README. |
| `templates/sprint-doc-template.md` | Standard sprint plan. |
| `templates/adr-template.md` | Architecture decision record. |
| `templates/ai-task-card-template.md` | AI implementation task card. |

## Documentation rule

If a new document overlaps with an existing document, update the existing document instead of creating another competing one.
