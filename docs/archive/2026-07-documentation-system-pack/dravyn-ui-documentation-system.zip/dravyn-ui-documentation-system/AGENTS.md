# AGENTS.md — Dravyn UI

## Project

Dravyn UI is a native-first enterprise UI foundation. It includes:

- `@dravyn/ui-core`
- `@dravyn/ui-components`
- `@dravyn/ui-data-grid`

Do not treat this repository as only a data-grid project.

## Required reading before work

1. `.ai/AI_CONTEXT.md`
2. `docs/README.md`
3. relevant package doc under `docs/packages/`
4. relevant architecture doc under `docs/architecture/`

## Forbidden dependencies by default

Do not add these unless explicitly approved:

- Redux / React Redux / RTK Query
- Zustand
- TanStack Table / Query / Virtual
- MUI / AntD / Chakra / Mantine
- Radix / Headless UI
- Tailwind
- styled-components / Emotion
- icon libraries
- CSS frameworks

## Package boundaries

- `ui-core` must not depend on `ui-components` or `ui-data-grid`.
- `ui-components` must not depend on `ui-data-grid`.
- `ui-data-grid` may depend on `ui-core` and `ui-components`.

## Styling rules

- Static styling belongs in CSS.
- TSX uses classes and dynamic CSS variables.
- Shared classes use `dv-*`.
- Grid classes use `udg-*`.
- Shared tokens use `--dv-*`.
- Grid variables use `--udg-*`.

## State rules

- No global store inside Dravyn packages.
- Use controlled/uncontrolled props.
- App owns backend rows, auth, permissions, and business workflows.
- Persistence/server/export use adapter contracts.

## Validation

Run after changes:

```bash
npm run build
npm run typecheck
npm run test
npm run build:playground
```

## Documentation

If public API changes, update:

- package README
- docs index if needed
- playground example
- AI docs if agent behavior changes
