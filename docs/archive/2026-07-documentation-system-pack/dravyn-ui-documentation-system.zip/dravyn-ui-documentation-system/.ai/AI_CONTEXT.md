# Dravyn UI — AI Context

## Project identity

Dravyn UI is a native-first enterprise UI foundation for internal tools, admin portals, customer portals, data-heavy applications, and workflow systems.

It is not only a data-grid package.

## Packages

| Package | Owns |
| --- | --- |
| `@dravyn/ui-core` | tokens, themes, density, utilities |
| `@dravyn/ui-components` | reusable native React components |
| `@dravyn/ui-data-grid` | UniversalDataGrid and grid-specific behavior |

## Hard rules

- Do not add Redux/Zustand/TanStack state inside Dravyn packages.
- Do not add MUI, AntD, Tailwind, Radix, Headless UI, styled-components, Emotion, or icon libraries by default.
- Keep native React + TypeScript + CSS.
- Keep static visual styling in CSS, not TSX.
- Use `--dv-*` tokens for shared design.
- Use `--udg-*` variables only for grid-specific styling.
- Do not store row data in grid state.
- Do not fetch data inside the grid package.
- Do not generate export files inside the grid package by default.
- Update docs and playground when public API changes.

## Dependency direction

Allowed:

- `ui-components -> ui-core`
- `ui-data-grid -> ui-core`
- `ui-data-grid -> ui-components`

Forbidden:

- `ui-core -> ui-components`
- `ui-components -> ui-data-grid`

## Required validation

Run after changes:

```bash
npm run build
npm run typecheck
npm run test
npm run build:playground
```
