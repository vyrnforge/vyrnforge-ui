# Dravyn UI — Documentation Usage Guide For AI

## Before implementing

1. Read `.ai/AI_CONTEXT.md`.
2. Read `docs/README.md`.
3. Read the relevant package doc under `docs/packages/`.
4. Read architecture rules if changing state, styling, or package boundaries.

## When updating docs

- Update the canonical doc instead of creating duplicates.
- Archive outdated docs under `docs/archive/`.
- Keep AI docs concise and practical.
- Add examples when public API changes.

## When unsure

Prefer:

- smaller API
- native-first implementation
- CSS variable theming
- controlled state
- adapter contracts
- no new dependency
