# Dravyn UI — Repo Map For AI

## Root

```txt
package.json
README.md
AGENTS.md
.ai/
docs/
packages/
examples/
```

## Packages

```txt
packages/ui-core/
packages/ui-components/
packages/ui-data-grid/
```

## Documentation

```txt
docs/README.md
docs/governance/
docs/architecture/
docs/roadmap/
docs/packages/
docs/react-docs/
docs/ai/
docs/templates/
docs/prompts/
```

## Where to put code

| Work | Location |
| --- | --- |
| shared tokens/themes | `packages/ui-core` |
| reusable component | `packages/ui-components/src/components/<Component>` |
| grid-specific behavior | `packages/ui-data-grid` |
| docs app example | `examples/basic-playground` or `apps/docs` |
| architecture docs | `docs/architecture` |
| component docs | component README + docs app page |

## Before creating new docs

Read `docs/README.md` and `docs/governance/00-documentation-governance.md`.
