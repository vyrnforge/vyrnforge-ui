# Dravyn UI Documentation System Pack

This pack defines a clean documentation system for **Dravyn UI** so the project does not drift into duplicated, conflicting, or table-only documentation.

Dravyn UI is a native-first enterprise UI foundation, not only a data-grid package. The intended package model is:

- `@dravyn/ui-core` — tokens, themes, density, utilities, CSS variables.
- `@dravyn/ui-components` — native React primitives and shared application components.
- `@dravyn/ui-data-grid` — specialized enterprise data-management grid.

Use this pack as the documentation governance baseline before adding more features.

## Recommended destination in the repo

Copy these files into the Dravyn UI repository:

```txt
repo-root/
  AGENTS.md
  .ai/
  docs/
    README.md
    governance/
    architecture/
    roadmap/
    packages/
    react-docs/
    ai/
    templates/
    prompts/
```

## How to use

1. Copy this pack into the repository root.
2. Run the documentation cleanup Codex prompt in `docs/prompts/01-doc-cleanup-and-unification.md`.
3. Move old duplicate docs into `docs/archive/` instead of deleting them immediately.
4. Make `docs/README.md` the single navigation entry for humans and AI.
5. Use `.ai/AI_CONTEXT.md` and `AGENTS.md` as the default AI working context.

## Core rule

There should be **one source of truth per topic**:

- Project positioning → `docs/governance/01-project-source-of-truth.md`
- Package boundaries → `docs/architecture/01-package-boundaries.md`
- State ownership → `docs/architecture/02-state-and-adapter-ownership.md`
- Roadmap → `docs/roadmap/00-master-roadmap.md`
- Component inventory → `docs/roadmap/01-component-inventory.md`
- React docs app → `docs/react-docs/00-react-docs-app-spec.md`
- AI usage → `.ai/AI_CONTEXT.md`
